#include "map.h"

unsigned int hash(char *key) {
  char *p = key;
  unsigned int  h = 37;
  while (*p != '\0') {
    h = h * 147 + *p++;
  }
  return h;
}

Map* mapNew(Map *map, Pair *list, int size, int top) {
  map->table = malloc(size*sizeof(Pair));
  memset(map->table, 0, size*sizeof(Pair));
  map->size = size;
  map->top = 0;
  printf("top=%d\n", top);
  for (int i=0; i<top; i++) {
    printf("%d : key=%s value=%s\n", i, list[i].key, list[i].value);
    mapAdd(map, list[i].key, list[i].value);
  }
  return map;
}

Pair mapAdd(Map *map, char *key, void *value) {
  assert(map->top < map->size);
  Pair p = { key, value };
  unsigned int h = hash(key) % map->size;
  while (map->table[h].key != NULL) {
    if (strcmp(map->table[h].key, key)==0) break;
    h = (h+1) % map->size;
  }
  printf("h=%d\n", h);
  map->table[h] = p;
  return p;
}

int mapFind(Map *map, char *key) {
  int h = hash(key) % map->size;
  while (map->table[h].key != NULL) {
    if (strcmp(map->table[h].key, key)==0) return h;
    h = (h+1) % map->size;
  }
  return -1;
}

void* mapLookup(Map *map, char *key) {
  int i = mapFind(map, key);
  if (i==-1) return NULL;
  return map->table[i].value;
}

void mapDump(Map *map) {
  printf("======= mapDump() ==============\n");
  for (int i=0; i<map->size; i++) {
    Pair *p = &map->table[i];
    printf("%d:  %s %s\n", i, p->key, (char*) p->value);
  }
}
